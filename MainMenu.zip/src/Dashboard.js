const Dashboard = () => {
    return (
   <div>Welcom to Your Dashboard</div>
);
};

export default Dashboard;