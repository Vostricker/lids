import { useState } from "react";
import NewJarPopup from "./NewJarPopup";

function MyJars() {
    const [ newJarPopupState, setNewJarPopupState ] = useState(false);
   
    function togglePopup() {
        setNewJarPopupState(!newJarPopupState);
    }

    return (
        <>
         <button onClick={togglePopup}>Create Jar</button>       
         <NewJarPopup popupOpen={newJarPopupState} setPopupState={{togglePopup}} />
        </>
        
    )
}

export default MyJars;