const Account = () => {
    return <div>Account Details</div>;
}

export default Account;