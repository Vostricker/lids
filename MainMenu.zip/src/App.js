import { Outlet } from "react-router-dom";
import "./App.css";
import Navbar from "./NavBar";
import logo from './JarReactTest2.png'

const App = () => {
    return (
        <>
          <img src={logo} className="App-logo" alt="logo" />
            <Navbar />
            
            <Outlet />
        </>
    );
};

export default App;